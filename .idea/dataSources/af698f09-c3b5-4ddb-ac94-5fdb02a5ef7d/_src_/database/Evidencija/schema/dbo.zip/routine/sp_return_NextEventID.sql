CREATE PROCEDURE [dbo].[sp_return_NextEventID] @EmployeeID INT, @ControllerID INT, @Date DATE, @Time TIME, @PressedButton INT
AS
/*
Events/Buttons:
	0 - Unknown
	1 - Regular Enter
	2 - Pause Enter
	3 - Official Enter
	4 - Personal Enter
	5 - Regular Exit
	6 - Pause Exit
	7 - Official Exit
	8 - Personal Exit
	9 - Enter, without registered exit
	10 - Exit, without registered enter
	11 - Passing
	12 - Unknown event
*/

DECLARE @LastEvent int, @LastValidEvent int, @HowManyControllerActivities int = 0, @DateTimeOfLastValidEvent DATETIME, @HowManyHoursAtWork DECIMAL(18, 2)
DECLARE @IsOnlyExit bit = 0, @IsOnlyEnter bit = 0, @IsOnlyForPassing bit = 1

DECLARE @CurrentEvent int = 0

--if @PressedButton <> 0
--begin
	select @CurrentEvent = case @PressedButton 
	when 0 then Btn1
	when 1 then Btn2
	when 2 then Btn3
	when 3 then Btn4
	when 4 then Btn1A
	when 5 then Btn2A
	when 6 then Btn3A
	when 7 then Btn4A
	end
	from Controllers
	where ControllerID = @ControllerID
	
	if @CurrentEvent > 0
	begin
		select @CurrentEvent as Event
		return
	end
--end

select @HowManyControllerActivities = cast(ActEnter as int) + cast(ActExit as int) + cast(ActOfficialEnter as int) + cast(ActOfficialExit as int) + 
	cast(ActPauseEnter as int) + cast(ActPauseExit as int) + cast(ActPersonalEnter as int) + cast(ActPersonalExit as int)
from Controllers
where ControllerID = @ControllerID

if @HowManyControllerActivities = 1
begin
	select @CurrentEvent = case 
		when ActEnter = 1 then 1
		when ActPauseEnter = 1 then 2
		when ActOfficialEnter = 1 then 3
		when ActPersonalEnter = 1 then 4
		when ActExit = 1 then 5
		when ActPauseExit = 1 then 6
		when ActOfficialExit = 1 then 7
		when ActPersonalExit = 1 then 8
	end from Controllers
	where ControllerID = @ControllerID

	select @CurrentEvent as Event
	return
end

select 
	@IsOnlyExit = case when (ActExit = 1 or ActPauseExit = 1 or ActOfficialExit = 1 or ActPersonalExit = 1)
						and ActEnter = 0 and ActPauseEnter = 0 and ActOfficialEnter = 0 and ActPersonalEnter = 0 then 1 else 0 end,
	@IsOnlyEnter = case when ActExit = 0 and ActPauseExit = 0 and ActOfficialExit = 0 and ActPersonalExit = 0
						and (ActEnter = 1 or ActPauseEnter = 1 or ActOfficialEnter = 1 or ActPersonalEnter = 1) then 1 else 0 end,
	@IsOnlyForPassing = case when ActExit = 0 and ActPauseExit = 0 and ActOfficialExit = 0 and ActPersonalExit = 0
						and ActEnter = 0 and ActPauseEnter = 0 and ActOfficialEnter = 0 and ActPersonalEnter = 0 then 1 else 0 end
from Controllers
where ControllerID = @ControllerID

if @IsOnlyForPassing = 1
begin
	set @CurrentEvent = 11
	select @CurrentEvent as Event
	return
end

select top 1 @LastEvent = EventTypeID from Events where EmployeeID = @EmployeeID and cast(Date as DateTime) + Time < cast(@Date as DateTime) + @Time AND ISNULL(Deleted, 0) = 0 order by Date desc, Time DESC
select top 1 @LastValidEvent = EventTypeID from Events where EmployeeID = @EmployeeID and cast(Date as DateTime) + Time < cast(@Date as DateTime) + @Time and EventTypeID between 1 and 10 AND ISNULL(Deleted, 0) = 0 order by Date desc, Time DESC
SELECT TOP 1 @DateTimeOfLastValidEvent = cast(Date as DateTime) + Time from Events where EmployeeID = @EmployeeID and cast(Date as DateTime) + Time < cast(@Date as DateTime) + @Time and EventTypeID between 1 and 10 AND ISNULL(Deleted, 0) = 0 order by Date desc, Time DESC
set @LastEvent = isnull(@LastEvent, 0)
set @LastValidEvent = isnull(@LastValidEvent, 0)
SELECT @HowManyHoursAtWork = WorkingHours FROM dbo.Employees WHERE EmployeeID = @EmployeeID

PRINT '@LastEvent = ' + CAST(@LastEvent AS VARCHAR(10)) + ', @LastValidEvent = ' + CAST(@LastValidEvent AS VARCHAR(10)) + ', @DateTimeOfLastValidEvent = ' + CAST(@DateTimeOfLastValidEvent AS VARCHAR(20))

-- make decision based on previous events and controller definitions
select @CurrentEvent = case 
	when @LastValidEvent = 0 and @IsOnlyEnter = 1 then 1 -- if no first event, and controller is enter only then regular enter
	when @LastValidEvent = 0 and @IsOnlyExit = 1 then 10 -- if no first event, and controller is exit only then enter without previous exit
	when @LastValidEvent = 0 and @IsOnlyEnter = 0 and @IsOnlyExit = 0 then 1 -- by default, first event in multifunctional controller is enter
	WHEN @LastValidEvent IN (1, 2, 3, 4, 9) AND DATEDIFF(HOUR, @DateTimeOfLastValidEvent, cast(@Date as DateTime) + @Time) > 2 * @HowManyHoursAtWork THEN 9
	when @LastValidEvent in (1, 2, 3, 4, 9) and ActExit = 1 then 5 -- if previous event is some enter and exit is allow then exit
	when @LastValidEvent in (1, 2, 3, 4, 9) and ActExit = 0 and ActOfficialExit = 1 then 7 -- if previous event is some enter and controller is not set for regular exit, but is for official exit then official exit
	when @LastValidEvent in (1, 2, 3, 4, 9) and ActExit = 0 and ActOfficialExit = 0 and ActPersonalExit = 1 then 8 -- if previous event is some enter and controller is not set for regular or official exit, but is for personal exit then personal exit
	when @LastValidEvent in (1, 2, 3, 4, 9) and ActExit = 0 and ActOfficialExit = 0 and ActPersonalExit = 0 and ActPauseExit = 1 then 6 -- if previous event is some enter and controller is not set for regular, official or personal exit, but is for pause exit then pause exit
	when @LastValidEvent = 5 and ActEnter = 1 then 1 -- if previous event is regular exit and controller is set for regular enter then regular enter
	when @LastValidEvent = 5 and ActEnter = 0 then 9 -- if previous event is regular exit and controller is NOT set for regular enter then enter without registered exit
	WHEN @LastValidEvent = 6 THEN 2
	WHEN @LastValidEvent = 7 THEN 3
	WHEN @LastValidEvent = 8 THEN 4
	else 12 -- unknown event!
end
from Controllers
where ControllerID = @ControllerID

select @CurrentEvent as Event
GO
