CREATE PROCEDURE [dbo].[sp_return_CardNumberForCardID] @CardID int
AS

declare @CardNumber varchar(50)=''

select @CardNumber = CardNumber
from Cards where CardID = @CardID

select @CardNumber
GO
