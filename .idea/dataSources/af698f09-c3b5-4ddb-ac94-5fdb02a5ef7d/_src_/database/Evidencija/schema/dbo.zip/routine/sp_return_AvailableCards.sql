CREATE PROCEDURE [dbo].[sp_return_AvailableCards] @EmployeeId INT = 0
AS
SELECT CardID, CardNumber FROM dbo.Cards c
WHERE IsActiveCard = 1
AND NOT EXISTS (SELECT * FROM dbo.EmployeeCards WHERE CardID = c.CardID AND ValidTo IS NULL)
AND NOT EXISTS (SELECT * FROM dbo.Visits WHERE CardID = c.CardID AND EndDateTime IS NULL)
UNION ALL
SELECT 0, ''
UNION ALL
SELECT CardID, CardNumber FROM dbo.Cards c
WHERE IsActiveCard = 1
AND EXISTS (SELECT * FROM dbo.EmployeeCards WHERE CardID = c.CardID AND EmployeeID = @EmployeeId)
ORDER BY 2
GO
