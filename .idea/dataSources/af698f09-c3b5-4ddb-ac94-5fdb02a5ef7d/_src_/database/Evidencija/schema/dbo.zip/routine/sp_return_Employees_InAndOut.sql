CREATE PROCEDURE [dbo].[sp_return_Employees_InAndOut] @EmployeeIDs VARCHAR(MAX), @EventTypeIDs VARCHAR(MAX)
AS

DECLARE @i INT, @s VARCHAR(100)

DECLARE @Employees TABLE (
	EmployeeID INT
)

WHILE @EmployeeIDs <> ''
BEGIN
	SET @i = CHARINDEX(',', @EmployeeIDs)
	if @i = 0
	BEGIN
		SET @s = RTRIM(LTRIM(@EmployeeIDs))
		SET @EmployeeIDs = ''
	END
	ELSE
	BEGIN
		SET @s = RTRIM(LTRIM(SUBSTRING(@EmployeeIDs, 1, @i-1)))
		SET @EmployeeIDs = SUBSTRING(@EmployeeIDs, @i+1, LEN(@EmployeeIDs))
	END
	
	SET @i = CAST(@s AS INT)
	INSERT INTO @Employees VALUES (@i)
END

DECLARE @EventTypes TABLE (
	EventTypeID INT
)

WHILE @EventTypeIDs <> ''
BEGIN
	SET @i = CHARINDEX(',', @EventTypeIDs)
	if @i = 0
	BEGIN
		SET @s = RTRIM(LTRIM(@EventTypeIDs))
		SET @EventTypeIDs = ''
	END
	ELSE
	BEGIN
		SET @s = RTRIM(LTRIM(SUBSTRING(@EventTypeIDs, 1, @i-1)))
		SET @EventTypeIDs = SUBSTRING(@EventTypeIDs, @i+1, LEN(@EventTypeIDs))
	END
	
	SET @i = CAST(@s AS INT)
	INSERT INTO @EventTypes VALUES (@i)
END

SELECT e.EventID, e.EmployeeID, e.EventTypeID, et.Description AS [LastEvent], emp.FirstName AS [FirstName], emp.LastName AS [LastName],
	d.DepartmentID, d.Name AS Department
FROM dbo.Events e
INNER JOIN dbo.Employees emp ON e.EmployeeID = emp.EmployeeID
LEFT OUTER JOIN dbo.Departments d ON emp.DepartmentID = d.DepartmentID
INNER JOIN dbo.EventTypes et ON e.EventTypeID = et.EventTypeID
WHERE 1 = 1
AND CASE WHEN NOT EXISTS(SELECT TOP 1 * FROM @Employees) THEN 1 WHEN e.EmployeeID IN (SELECT EmployeeID FROM @Employees) THEN 1 ELSE 0 END = 1
AND CASE WHEN NOT EXISTS(SELECT TOP 1 * FROM @EventTypes) THEN 1 WHEN e.EventTypeID IN (SELECT EventTypeID FROM @EventTypes) THEN 1 ELSE 0 END = 1
AND e.EventID = (SELECT TOP 1 EventID FROM dbo.Events WHERE EmployeeID = e.EmployeeID AND EventTypeID BETWEEN 1 AND 10 ORDER BY Date DESC, Time DESC)
ORDER BY d.Name, emp.FirstName, emp.LastName
GO
