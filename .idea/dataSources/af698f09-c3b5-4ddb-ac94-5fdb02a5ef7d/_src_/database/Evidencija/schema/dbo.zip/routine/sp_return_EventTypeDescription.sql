CREATE PROCEDURE [dbo].[sp_return_EventTypeDescription] @EventTypeID int
AS

select Description from EventTypes
where EventTypeID = @EventTypeID
GO
