CREATE PROCEDURE [dbo].[sp_return_CardIDForCardNumber] @CardNumber varchar(50)
AS

declare @CardID int = 0

select @CardID = CardID
from Cards where CardNumber = @CardNumber

select @CardID
GO
