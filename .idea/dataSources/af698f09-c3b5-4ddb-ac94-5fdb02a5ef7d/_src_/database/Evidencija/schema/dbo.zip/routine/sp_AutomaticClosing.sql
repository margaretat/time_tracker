CREATE PROCEDURE dbo.sp_AutomaticClosing
AS

DECLARE @EventID INT, @LastEventTypeID INT, @WorkingHours DECIMAL(9, 2), @DateDiff DECIMAL(9, 2)

DECLARE Emp CURSOR FOR
SELECT EventID, EventTypeID, WorkingHours, DATEDIFF(HOUR, cast(Date as DateTime) + Time, GETDATE())
FROM dbo.Events ev
INNER JOIN dbo.Employees em ON ev.EmployeeID = em.EmployeeID
WHERE em.WorkingHours > 0
AND ev.EventID = (SELECT TOP 1 EventID FROM dbo.Events WHERE EmployeeID = em.EmployeeID AND EventTypeID BETWEEN 1 AND 10 ORDER BY Date DESC, Time desc)
AND ISNULL(ev.Deleted, 0) = 0
ORDER BY em.PersonalNumber

OPEN Emp

FETCH NEXT FROM Emp INTO @EventID, @LastEventTypeID, @WorkingHours, @DateDiff

WHILE @@FETCH_STATUS = 0
BEGIN
	IF @LastEventTypeID IN (1, 2, 3, 4, 6, 7, 9) AND @DateDiff > 1.5 * @WorkingHours
	BEGIN
		INSERT INTO dbo.Events (ControllerID, Date, Time, UsedButton, EventTypeID, CardID, CardNumber, EmployeeID, EmployeeName, PersonalNumber)
		SELECT 0, DATEADD(DAY, @WorkingHours / 24, Date), DATEADD(HOUR, @WorkingHours, Time), 0, 5, CardID, CardNumber, EmployeeID, EmployeeName, PersonalNumber
		FROM dbo.Events
		WHERE EventID = @EventID
	END

	IF @LastEventTypeID IN (6, 7) AND @DateDiff > 1.5 * @WorkingHours
	BEGIN
		INSERT INTO dbo.Events (ControllerID, Date, Time, UsedButton, EventTypeID, CardID, CardNumber, EmployeeID, EmployeeName, PersonalNumber)
		SELECT 0, DATEADD(SECOND, -1, DATEADD(DAY, @WorkingHours / 24, Date)), DATEADD(SECOND, -1, DATEADD(HOUR, @WorkingHours, Time)), 0, 5, CardID, CardNumber, EmployeeID, EmployeeName, PersonalNumber
		FROM dbo.Events
		WHERE EventID = @EventID
	END
	
	FETCH NEXT FROM Emp INTO @EventID, @LastEventTypeID, @WorkingHours, @DateDiff
END

CLOSE Emp
DEALLOCATE Emp
GO
