CREATE PROCEDURE [dbo].[sp_return_Controllers]
AS

SELECT *, DENSE_RANK() OVER (ORDER BY Comm, IPAddress) AS LineID FROM Controllers
GO
