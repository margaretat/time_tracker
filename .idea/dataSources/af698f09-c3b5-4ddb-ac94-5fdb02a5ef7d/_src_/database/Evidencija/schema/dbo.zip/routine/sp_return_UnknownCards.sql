CREATE PROCEDURE [dbo].[sp_return_UnknownCards]
AS
select distinct cast(0 as Bit) as Checked, CardNumber from Events
where EventTypeId in (0, 12) and CardNumber not in (select CardNumber from Cards)
GO
