CREATE PROCEDURE [dbo].[sp_return_EmployeeIDForCardNumber] @CardNumber varchar(50)
AS

declare @EmployeeID int = 0

select @EmployeeID = EmployeeID
from EmployeeCards ec
inner join Cards c on ec.CardID = c.CardID and c.CardNumber = @CardNumber
where isnull(ValidTo, dateadd(day, 1, getdate())) >= getdate()

select @EmployeeID
GO
