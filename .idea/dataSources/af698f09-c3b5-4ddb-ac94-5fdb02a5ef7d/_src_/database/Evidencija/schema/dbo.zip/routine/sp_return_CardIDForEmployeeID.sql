CREATE PROCEDURE [dbo].[sp_return_CardIDForEmployeeID] @EmployeeID INT
AS

DECLARE @Res INT = 0

SELECT @Res = CardID
FROM EmployeeCards
WHERE EmployeeID = @EmployeeID
AND ValidTo IS NULL

SELECT @Res
GO
