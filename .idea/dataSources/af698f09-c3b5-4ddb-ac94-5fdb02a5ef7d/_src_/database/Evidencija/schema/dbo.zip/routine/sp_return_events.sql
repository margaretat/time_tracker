CREATE PROCEDURE [dbo].[sp_return_events] @FromDateTime datetime, @ToDateTime datetime, @Enter int, @Exit int,
	@CardIDs VARCHAR(MAX), @EventTypeIDs VARCHAR(MAX), @EmployeeIDs VARCHAR(MAX), @PauseInWT bit = 1,
	@WithoutOvertime BIT = 0, @IncludeSaturdays BIT = 1, @IncludeSundays BIT = 1, @IncludeHolidays BIT = 1,
	@WorkTimes VARCHAR(MAX)
AS

create table #aaa (
	ID int not null identity(1, 1),
	ControllerID int,
	Date date,
	Time time,
	CardNumber varchar(50),
	CardID INT,
	PersonalNumber nvarchar(13),
	EventTypeID int,
	EventDescription nvarchar(100),
	EmployeeID int,
	EmployeeName nvarchar(150),
	DepartmentName nvarchar(200),
	ControllerDescription nvarchar(500),
	WorkingHours decimal(9, 2),
	Dossier varchar(20),
	RealDate date,
	RealTime time
)

declare @s varchar(100), @i int

declare @Delete table (
	ID int
)

declare @Cards table (
	CardID int
)

declare @EventTypes table (
	EventTypeID int
)

declare @Employees table (
	EmployeeID int
)

declare @WorkingHours table (
	WorkingHourID int
)

while @CardIDs <> ''
begin
	set @i = charindex(',', @CardIDs)
	if @i = 0
	begin
		set @s = rtrim(ltrim(@CardIDs))
		set @CardIDs = ''
	end
	else
	begin
		set @s = rtrim(ltrim(substring(@CardIDs, 1, @i-1)))
		set @CardIDs = substring(@CardIDs, @i+1, len(@CardIDs))
	end
	
	set @i = cast(@s as int)
	insert into @Cards values (@i)
end

while @EventTypeIDs <> ''
begin
	set @i = charindex(',', @EventTypeIDs)
	if @i = 0
	begin
		set @s = rtrim(ltrim(@EventTypeIDs))
		set @EventTypeIDs = ''
	end
	else
	begin
		set @s = rtrim(ltrim(substring(@EventTypeIDs, 1, @i-1)))
		set @EventTypeIDs = substring(@EventTypeIDs, @i+1, len(@EventTypeIDs))
	end
	
	set @i = cast(@s as int)
	insert into @EventTypes values (@i)
end

while @EmployeeIDs <> ''
begin
	set @i = charindex(',', @EmployeeIDs)
	if @i = 0
	begin
		set @s = rtrim(ltrim(@EmployeeIDs))
		set @EmployeeIDs = ''
	end
	else
	begin
		set @s = rtrim(ltrim(substring(@EmployeeIDs, 1, @i-1)))
		set @EmployeeIDs = substring(@EmployeeIDs, @i+1, len(@EmployeeIDs))
	end
	
	set @i = cast(@s as int)
	insert into @Employees values (@i)
end

while @WorkTimes <> ''
begin
	set @i = charindex(',', @WorkTimes)
	if @i = 0
	begin
		set @s = rtrim(ltrim(@WorkTimes))
		set @WorkTimes = ''
	end
	else
	begin
		set @s = rtrim(ltrim(substring(@WorkTimes, 1, @i-1)))
		set @WorkTimes = substring(@WorkTimes, @i+1, len(@WorkTimes))
	end
	
	set @i = cast(@s as int)
	insert into @WorkingHours values (@i)
END

-- filling events
insert into #aaa (ControllerID, Date, Time, CardNumber, CardID, PersonalNumber, EventTypeID, EventDescription, EmployeeID,
	EmployeeName, DepartmentName, ControllerDescription, WorkingHours, Dossier, RealDate, RealTime)

select ev.ControllerID, ev.Date, ev.Time, ev.CardNumber, ev.CardID, ev.PersonalNumber, ev.EventTypeID, et.Description, ev.EmployeeID,
	em.LastName + ' ' + em.FirstName, de.Name, co.Description, em.WorkingHours, em.Dossier, ev.RealDate, ev.RealTime
from Events ev
left join Controllers co on ev.ControllerID = co.ControllerID
inner join Cards ca on ev.CardID = ca.CardID
inner join Employees em on ev.EmployeeID = em.EmployeeID
inner join EventTypes et on ev.EventTypeID = et.EventTypeID
LEFT join Departments de on em.DepartmentID = de.DepartmentID
where cast(ev.Date as datetime) + cast(ev.Time as datetime) between @FromDateTime and @ToDateTime
	and case when not exists(select top 1 * from @Cards) then 1 when ev.CardID in (select CardID from @Cards) then 1 else 0 end = 1
	and case when not exists(select top 1 * from @Employees) then 1 when ev.EmployeeID in (select EmployeeID from @Employees) then 1 else 0 end = 1
	and case when not exists(select top 1 * from @EventTypes) then 1 when ev.EventTypeID in (select EventTypeID from @EventTypes) then 1 else 0 end = 1
	and ev.EventTypeID between 1 and 10
	AND ISNULL(ev.Deleted, 0) = 0
order by de.Name, em.LastName, em.FirstName, ev.Date, ev.Time

declare @oEmployeeID int, @oEventTypeID int, @oID int
declare @EmployeeID int, @Date Date, @Time Time, @EventTypeID int, @ID int

-- change pause enter/exit with regular enter/exit if pause is not included in worktime
if @PauseInWT = 0
begin
	update #aaa
	set EventTypeID = 1
	where EventTypeID = 2

	update #aaa
	set EventTypeID = 5
	where EventTypeID = 6
end

-- replace enter/exit without registered ... with regular enter exit
update #aaa
set EventTypeID = 1
where EventTypeID = 9

update #aaa
set EventTypeID = 5
where EventTypeID = 10

-- start checking for duplicates
select @oEmployeeID=0, @oEventTypeID=-100

DECLARE ccc CURSOR FOR
SELECT ID, EmployeeID, Date, Time, EventTypeID
FROM #aaa
order by EmployeeID, Date, Time

OPEN ccc

FETCH NEXT FROM ccc INTO @ID, @EmployeeID, @Date, @Time, @EventTypeID

WHILE @@FETCH_STATUS = 0
BEGIN
	if @EmployeeID = @oEmployeeID and @EventTypeID = @oEventTypeID and @EventTypeID in (1, 2, 3, 4, 9)
	begin
	if @Enter = 0
		insert into @Delete values (@ID)
	else
		insert into @Delete values (@oID)
	end

	if @EmployeeID = @oEmployeeID and @EventTypeID = @oEventTypeID and @EventTypeID in (5, 6, 7, 8, 10)
	begin
	if @Exit = 0
		insert into @Delete values (@ID)
	else
		insert into @Delete values (@oID)
	end

	select @oEmployeeID = @EmployeeID, @oEventTypeID = @EventTypeID, @oID = @ID

	FETCH NEXT FROM ccc INTO @ID, @EmployeeID, @Date, @Time, @EventTypeID
END

CLOSE ccc
DEALLOCATE ccc

delete from #aaa where ID in (select ID from @Delete)

---- Time correction
--SET DATEFIRST 1

--update #aaa
--set vreme = pv.vreme_novo
--from @aaa a, PROMENETI_VREMINJA pv
--where a.status=1 and pv.vlezizlez='V' and pv.dali_vazi = 'D'
--and power(2, datepart(dw, cast(a.datum as datetime))-1) & pv.denovi <> 0
--and (select count(*) from praznici where datum=a.datum)=0
--and a.vreme between pv.vreme_od and pv.vreme_do

--update #aaa
--set vreme = pv.vreme_novo
--from @aaa a, PROMENETI_VREMINJA pv
--where a.status=2 and pv.vlezizlez='I' and pv.dali_vazi = 'D'
--and power(2, datepart(dw, cast(a.datum as datetime))-1) & pv.denovi <> 0
--and (select count(*) from praznici where datum=a.datum)=0
--and a.vreme between pv.vreme_od and pv.vreme_do

--update #aaa
--set vreme = pv.vreme_novo
--from @aaa a, PROMENETI_VREMINJA pv
--where a.status=1 and pv.vlezizlez='V' and pv.dali_vazi = 'D'
--and 128 & pv.denovi <> 0
--and (select count(*) from praznici where datum=a.datum)<>0
--and a.vreme between pv.vreme_od and pv.vreme_do

--update #aaa
--set vreme = pv.vreme_novo
--from @aaa a, PROMENETI_VREMINJA pv
--where a.status=2 and pv.vlezizlez='I' and pv.dali_vazi = 'D'
--and 128 & pv.denovi <> 0
--and (select count(*) from praznici where datum=a.datum)<>0
--and a.vreme between pv.vreme_od and pv.vreme_do

--SET DATEFIRST 7


CREATE TABLE #Report (
	ID int identity,
	EmployeeID int,
	EmployeeName nvarchar(150),
	DepartmentName nvarchar(200),
	CardID INT,
	DateIn date,
	TimeIn time,
	LastTimeIn time,
	DateOut date,
	TimeOut time,
	HoursAtWork decimal(9, 2),
	NoOfEnters int,
	Overtime decimal(9, 2),
	EarlyIn decimal(9, 2),
	LateIn decimal(9, 2),
	EarlyOut decimal(9, 2),
	LateOut decimal(9, 2),
	TimeOfPause decimal(9, 2),
	NoOfPauses int,
	MorePause decimal(9, 2),
	EarlyPauseOut decimal(9, 2),
	LatePauseIn decimal(9, 2),
	TimeOfOfficials decimal(9, 2),
	NoOfOfficials int,
	TimeOfPersonals decimal(9, 2),
	NoOfPersonals int,
	Note varchar(100),
	WorkingHourID INT,

	TotalHoursAtWork decimal(9, 2),
	TotalOvertime decimal(9, 2),
	TotalEarlyIn decimal(9, 2),
	TotalLateIn decimal(9, 2),
	TotalEarlyOut decimal(9, 2),
	TotalLateOut decimal(9, 2),
	TotalTimeOfPause decimal(9, 2),
	TotalMorePause decimal(9, 2),
	TotalEarlyPauseOut decimal(9, 2),
	TotalLatePauseIn decimal(9, 2),
	TotalTimeOfOfficials decimal(9, 2),
	TotalTimeOfPersonals decimal(9, 2)

)

--select * from #aaa --<>--
--order by DepartmentName, EmployeeName, isnull(RealDate, Date), isnull(RealTime, Time) --<>--

-- insert of first and last daily enter for every employee/date
insert into #Report (EmployeeID, CardID, EmployeeName, DepartmentName, DateIn, TimeIn, LastTimeIn)
select EmployeeID, CardID, EmployeeName, DepartmentName, Date, Min(Time), Max(Time)
from #aaa
where EventTypeId = 1
group by EmployeeID, CardID, EmployeeName, DepartmentName, Date

--select * from #Report --//--

-- update data with first exit after last daily enter
update r
SET DateOut = a.Date, TimeOut = a.Time
FROM #Report r
INNER JOIN #aaa a ON r.EmployeeID = a.EmployeeID
	AND a.ID = (SELECT TOP 1 ID FROM #aaa WHERE r.EmployeeID = EmployeeID AND EventTypeID = 5 AND 
					CAST(Date AS DATETIME) + CAST(Time AS DATETIME) > CAST(r.DateIn AS DATETIME) + CAST(r.LastTimeIn AS DATETIME) ORDER BY Date, Time)

--set DateOut = ttt.DateOut, TimeOut = ttt.TimeOut
--from (
--	select TOP 1 r.EmployeeID, r.DateIn, r.TimeIn, a.Date as DateOut, a.Time as TimeOut
--	from #Report r
--	inner join #aaa a on r.EmployeeID = a.EmployeeID and a.EventTypeID = 5 
--		and cast(a.Date as datetime) + cast(a.Time as datetime) > cast(r.DateIn as datetime) + cast(r.LastTimeIn as datetime)
--	ORDER BY a.Date, a.Time
--) as ttt
--inner join #Report r on r.EmployeeID = ttt.EmployeeID and r.DateIn = ttt.DateIn and r.TimeIn = ttt.TimeIn

--select * from #Report --//--

-- delete the enters without exit
delete from #Report
where DateOut is null

--select * from #Report --//--

-- delete all first enters with exit in same date/time
delete from #Report
where cast(EmployeeID as varchar(10)) + convert(varchar(10), DateIn, 102) + convert(varchar(8), TimeIn, 108) in
(
	select cast(EmployeeID as varchar(10)) + convert(varchar(10), Min(DateIn), 102) + convert(varchar(8), Min(TimeIn), 108)
	from #Report 
	where cast(EmployeeID as varchar(10)) + convert(varchar(10), DateOut, 102) + convert(varchar(8), TimeOut, 108) in 
	(
		select cast(EmployeeID as varchar(10)) + convert(varchar(10), DateOut, 102) + convert(varchar(8), TimeOut, 108)
		from #Report
		group by EmployeeID, DateOut, TimeOut
		having count(*) > 1
	)
	group by EmployeeID
)

-- attach suitable working times
-- 1st step, set times for employees with added working times
UPDATE #report
SET WorkingHourID =
(
	SELECT TOP 1 wh.WorkingHourID
	FROM dbo.WorkingHours wh
	INNER JOIN dbo.EmployeeWorkingHours ewh ON wh.WorkingHourID = ewh.WorkingHourID
	WHERE ewh.EmployeeID = #report.EmployeeID
	ORDER BY ABS(DATEDIFF(SECOND, #report.TimeIn, wh.StartingFrom)) + ABS(DATEDIFF(SECOND, #report.TimeOut, wh.EndingFrom))
)
-- 2nd step, set times for employees without added working times
UPDATE #report
SET WorkingHourID =
(
	SELECT TOP 1 wh.WorkingHourID
	FROM dbo.WorkingHours wh
	ORDER BY ABS(DATEDIFF(SECOND, #report.TimeIn, wh.StartingFrom)) + ABS(DATEDIFF(SECOND, #report.TimeOut, wh.EndingFrom))
)
WHERE WorkingHourID IS NULL

IF EXISTS(SELECT TOP 1 * FROM @WorkingHours)
	DELETE FROM #report
	WHERE WorkingHourID NOT IN (SELECT WorkingHourID FROM @WorkingHours)

-- calculate time at work
update r
set HoursAtWork = cast(ttt.Seconds as decimal(9, 2)) / 3600, NoOfEnters = HowMany
from (
	select r.EmployeeID, r.ID, sum(datediff(second, cast(rin.Date as datetime) + cast(rin.Time as datetime), cast(rout.Date as datetime) + cast(rout.Time as datetime))) as Seconds, count(rin.ID) as HowMany
	from #Report r
	inner join #aaa rin on r.EmployeeID = rin.EmployeeId and rin.EventTypeId = 1
		and cast(rin.Date as datetime) + cast(rin.Time as datetime) between cast(r.DateIn as datetime) + cast(r.TimeIn as datetime) and cast(r.DateOut as datetime) + cast(r.TimeOut as datetime)
	inner join #aaa rout on rout.ID = (select top 1 ID from #aaa where EventTypeId = 5 AND EmployeeID = rin.EmployeeId and cast(Date as datetime) + cast(Time as datetime) > cast(rin.Date as datetime) + cast(rin.Time as datetime) order by Date, Time)
	group by r.EmployeeId, r.ID
) as ttt
inner join #Report r on ttt.ID = r.ID

-- calculate pauses
update r
set TimeOfPause = cast(ttt.Seconds as decimal(9, 2)) / 3600, NoOfPauses = HowMany
from (
	select r.EmployeeID, r.ID, sum(datediff(second, cast(rin.Date as datetime) + cast(rin.Time as datetime), cast(rout.Date as datetime) + cast(rout.Time as datetime))) as Seconds, count(rin.ID) as HowMany
	from #Report r
	inner join #aaa rin on r.EmployeeID = rin.EmployeeId and rin.EventTypeId = 6
		and cast(rin.Date as datetime) + cast(rin.Time as datetime) between cast(r.DateIn as datetime) + cast(r.TimeIn as datetime) and cast(r.DateOut as datetime) + cast(r.TimeOut as datetime)
	inner join #aaa rout on rout.ID = (select top 1 ID from #aaa where EventTypeId = 2 AND EmployeeID = rin.EmployeeId and cast(Date as datetime) + cast(Time as datetime) > cast(rin.Date as datetime) + cast(rin.Time as datetime) order by Date, Time)
	group by r.EmployeeId, r.ID
) as ttt
inner join #Report r on ttt.ID = r.ID

-- check if more pause
UPDATE r
SET MorePause = (TimeOfPause * 60 - TotalMinutes) / 60
from (
	SELECT wh.WorkingHourID, SUM(p.TotalMinutes) AS TotalMinutes
	FROM dbo.Pauses p
	INNER JOIN dbo.WorkingHours wh ON p.WorkingHourID = wh.WorkingHourID
	GROUP BY wh.WorkingHourID
) as ttt
inner join #Report r ON ttt.WorkingHourID = r.WorkingHourID
AND TimeOfPause * 60 > TotalMinutes

-- calculate officials
update r
set TimeOfOfficials = cast(ttt.Seconds as decimal(9, 2)) / 3600, NoOfOfficials = HowMany
from (
	select r.EmployeeID, r.ID, sum(datediff(second, cast(rin.Date as datetime) + cast(rin.Time as datetime), cast(rout.Date as datetime) + cast(rout.Time as datetime))) as Seconds, count(rin.ID) as HowMany
	from #Report r
	inner join #aaa rin on r.EmployeeID = rin.EmployeeId and rin.EventTypeId = 7
		and cast(rin.Date as datetime) + cast(rin.Time as datetime) between cast(r.DateIn as datetime) + cast(r.TimeIn as datetime) and cast(r.DateOut as datetime) + cast(r.TimeOut as datetime)
	inner join #aaa rout on rout.ID = (select top 1 ID from #aaa where EventTypeId = 3 AND EmployeeID = rin.EmployeeId and cast(Date as datetime) + cast(Time as datetime) > cast(rin.Date as datetime) + cast(rin.Time as datetime) order by Date, Time)
	group by r.EmployeeId, r.ID
) as ttt
inner join #Report r on ttt.ID = r.ID

-- calculate personals
update r
set TimeOfPersonals = cast(ttt.Seconds as decimal(9, 2)) / 3600, NoOfPersonals = HowMany
from (
	select r.EmployeeID, r.ID, sum(datediff(second, cast(rin.Date as datetime) + cast(rin.Time as datetime), cast(rout.Date as datetime) + cast(rout.Time as datetime))) as Seconds, count(rin.ID) as HowMany
	from #Report r
	inner join #aaa rin on r.EmployeeID = rin.EmployeeId and rin.EventTypeId = 8
		and cast(rin.Date as datetime) + cast(rin.Time as datetime) between cast(r.DateIn as datetime) + cast(r.TimeIn as datetime) and cast(r.DateOut as datetime) + cast(r.TimeOut as datetime)
	inner join #aaa rout on rout.ID = (select top 1 ID from #aaa where EventTypeId = 4 AND EmployeeID = rin.EmployeeId and cast(Date as datetime) + cast(Time as datetime) > cast(rin.Date as datetime) + cast(rin.Time as datetime) order by Date, Time)
	group by r.EmployeeId, r.ID
) as ttt
inner join #Report r on ttt.ID = r.ID

-- if enters and exits are in allowed limits, update times
UPDATE r
SET HoursAtWork = r.HoursAtWork - CAST(DATEDIFF(SECOND, r.TimeIn, wh.StartingFrom) AS DECIMAL(12, 5)) / 3600
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, r.TimeIn, wh.StartingFrom) <= wh.BeforeStaringFromTimeLimit
	AND DATEDIFF(MINUTE, r.TimeIn, wh.StartingFrom) > 0

UPDATE r
SET TimeIn = wh.StartingFrom
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, r.TimeIn, wh.StartingFrom) <= wh.BeforeStaringFromTimeLimit
	AND DATEDIFF(MINUTE, r.TimeIn, wh.StartingFrom) > 0

UPDATE r
SET HoursAtWork = r.HoursAtWork - CAST(DATEDIFF(SECOND, wh.EndingFrom, r.TimeOut) AS DECIMAL(12, 5)) / 3600
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, wh.EndingFrom, r.TimeOut) <= wh.AfterEndingFromTimeLimit
	AND DATEDIFF(MINUTE, wh.EndingFrom, r.TimeOut) > 0

UPDATE r
SET TimeOut = wh.EndingFrom
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, wh.EndingFrom, r.TimeOut) <= wh.AfterEndingFromTimeLimit
	AND DATEDIFF(MINUTE, wh.EndingFrom, r.TimeOut) > 0

-- calculate late in
UPDATE r
SET LateIn = CAST(DATEDIFF(SECOND, wh.StartingFrom, r.TimeIn) AS DECIMAL(12, 5)) / 3600
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, r.TimeIn, wh.StartingFrom) < 0

-- calculate early out
UPDATE r
SET EarlyOut = CAST(DATEDIFF(SECOND, r.TimeOut, wh.EndingFrom) AS DECIMAL(12, 5)) / 3600
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, wh.EndingFrom, r.TimeOut) < 0

-- calculate early in
UPDATE r
SET EarlyIn = CAST(DATEDIFF(SECOND, r.TimeIn, wh.StartingFrom) AS DECIMAL(12, 5)) / 3600
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, r.TimeIn, wh.StartingFrom) > 0

-- calculate late out
UPDATE r
SET LateOut = CAST(DATEDIFF(SECOND, wh.EndingFrom, r.TimeOut) AS DECIMAL(12, 5)) / 3600
FROM #Report r
INNER JOIN dbo.WorkingHours wh ON r.WorkingHourID = wh.WorkingHourID AND DATEDIFF(MINUTE, wh.EndingFrom, r.TimeOut) > 0

-- insert leaves
DECLARE @Dates TABLE ([Date] DATE);

WITH mycte AS
(
	SELECT @FromDateTime DateValue
	UNION ALL
	SELECT  DateValue + 1
	FROM    mycte   
	WHERE   DateValue + 1 <= @ToDateTime
)
INSERT INTO @Dates
SELECT  DateValue
FROM    mycte
OPTION (MAXRECURSION 0)

SET DATEFIRST 1

INSERT INTO #Report (EmployeeID, EmployeeName, DepartmentName, DateIn, Note)
SELECT e.EmployeeID, e.LastName + ' ' + e.FirstName, de.Name, d.Date, lt.Name
FROM @Dates d
CROSS JOIN dbo.Leaves l
INNER JOIN dbo.Employees e ON l.EmployeeID = e.EmployeeID
LEFT JOIN dbo.Departments de ON e.DepartmentID = de.DepartmentID
INNER JOIN dbo.LeaveTypes lt ON l.LeaveTypeID = lt.LeaveTypeID
WHERE d.Date BETWEEN l.FromDate AND ISNULL(l.ToDate, GETDATE())
--	AND DATEPART(WEEKDAY, d.Date) <= 5
-- end of leaves

-- calculate overtimes
UPDATE r SET HoursAtWork = e.WorkingHours, Overtime = HoursAtWork - e.WorkingHours
FROM #Report r
INNER JOIN dbo.Employees e ON r.EmployeeId = e.EmployeeID AND r.HoursAtWork > e.WorkingHours

-- if required, hide the overtime
IF @WithoutOvertime = 1
	UPDATE #report
	SET Overtime = NULL

-- if required, remove saturdays
IF @IncludeSaturdays = 0
BEGIN
	DELETE FROM #report
	WHERE DATEPART(WEEKDAY, DateIn) = 6
	
	DELETE FROM #report
	WHERE DATEPART(WEEKDAY, DateOut) = 6
END

-- insert "empty" days
INSERT INTO #Report (EmployeeID, DateIn, EmployeeName, DepartmentName)
SELECT e.EmployeeID, d.Date, e.LastName + ' ' + e.FirstName, dd.Name
FROM dbo.Employees e
CROSS JOIN @Dates d
LEFT JOIN dbo.Departments dd ON e.DepartmentID = dd.DepartmentID
WHERE e.Active = 1
AND NOT EXISTS(SELECT * FROM #Report WHERE EmployeeID = e.EmployeeID AND DateIn = d.Date)
	and case when not exists(select top 1 * from @Employees) then 1 when e.EmployeeID in (select EmployeeID from @Employees) then 1 else 0 end = 1


-- if required, remove sundays
IF @IncludeSundays = 0
BEGIN
	DELETE FROM #report
	WHERE DATEPART(WEEKDAY, DateIn) = 7
	
	DELETE FROM #report
	WHERE DATEPART(WEEKDAY, DateOut) = 7
END

-- if required, remove holidays
IF @IncludeHolidays = 0
BEGIN
	-- delete public holidays
	DELETE FROM #report
	WHERE DateIn IN (SELECT Date FROM dbo.Holidays WHERE ReligionID = 0)
	
	DELETE FROM #report
	WHERE DateOut IN (SELECT Date FROM dbo.Holidays WHERE ReligionID = 0)

	-- delete holidays by religions
	DELETE FROM #report
	WHERE DateIn IN (SELECT Date FROM dbo.Holidays WHERE ReligionID = (SELECT ReligionID FROM dbo.Employees WHERE EmployeeID = #report.EmployeeID))
	
	DELETE FROM #report
	WHERE DateOut IN (SELECT Date FROM dbo.Holidays WHERE ReligionID = (SELECT ReligionID FROM dbo.Employees WHERE EmployeeID = #report.EmployeeID))
END

-- calculate the total times
UPDATE r
SET TotalHoursAtWork = t.TotalHoursAtWork, TotalOvertime = t.TotalOvertime, TotalEarlyIn = t.TotalEarlyIn, TotalLateIn = t.TotalLateIn,
	TotalEarlyOut = t.TotalEarlyOut, TotalLateOut = t.TotalLateOut, TotalTimeOfPause = t.TotalTimeOfPause, TotalMorePause = t.TotalMorePause,
	TotalEarlyPauseOut = t.TotalEarlyPauseOut, TotalLatePauseIn = t.TotalLatePauseIn, TotalTimeOfOfficials = t.TotalTimeOfOfficials,
	TotalTimeOfPersonals = t.TotalTimeOfPersonals
FROM #Report r
INNER JOIN (
	SELECT EmployeeID, 
		SUM(HoursAtWork) AS TotalHoursAtWork,
		SUM(Overtime) AS TotalOvertime,
		SUM(EarlyIn) AS TotalEarlyIn,
		SUM(LateIn) AS TotalLateIn,
		SUM(EarlyOut) AS TotalEarlyOut,
		SUM(LateOut) AS TotalLateOut,
		SUM(TimeOfPause) AS TotalTimeOfPause,
		SUM(MorePause) AS TotalMorePause,
		SUM(EarlyPauseOut) AS TotalEarlyPauseOut,
		SUM(LatePauseIn) AS TotalLatePauseIn,
		SUM(TimeOfOfficials) AS TotalTimeOfOfficials,
		SUM(TimeOfPersonals) AS TotalTimeOfPersonals
	FROM #Report
	GROUP BY EmployeeID
) AS t ON r.EmployeeId = t.EmployeeID

select *,
CAST(RIGHT('0' + CAST (FLOOR(HoursAtWork) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((HoursAtWork * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((HoursAtWork * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sHoursAtWork,
CAST(RIGHT('0' + CAST (FLOOR(Overtime) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((Overtime * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((Overtime * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sOvertime,
CAST(RIGHT('0' + CAST (FLOOR(EarlyIn) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((EarlyIn * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((EarlyIn * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sEarlyIn,
CAST(RIGHT('0' + CAST (FLOOR(LateIn) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((LateIn * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((LateIn * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sLateIn,
CAST(RIGHT('0' + CAST (FLOOR(EarlyOut) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((EarlyOut * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((EarlyOut * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sEarlyOut,
CAST(RIGHT('0' + CAST (FLOOR(LateOut) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((LateOut * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((LateOut * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sLateOut,
CAST(RIGHT('0' + CAST (FLOOR(TimeOfPause) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TimeOfPause * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TimeOfPause * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTimeOfPause,
CAST(RIGHT('0' + CAST (FLOOR(MorePause) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((MorePause * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((MorePause * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sMorePause,
CAST(RIGHT('0' + CAST (FLOOR(EarlyPauseOut) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((EarlyPauseOut * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((EarlyPauseOut * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sEarlyPauseOut,
CAST(RIGHT('0' + CAST (FLOOR(LatePauseIn) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((LatePauseIn * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((LatePauseIn * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sLatePauseIn,
CAST(RIGHT('0' + CAST (FLOOR(TimeOfOfficials) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TimeOfOfficials * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TimeOfOfficials * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTimeOfOfficials,
CAST(RIGHT('0' + CAST (FLOOR(TimeOfPersonals) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TimeOfPersonals * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TimeOfPersonals * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTimeOfPersonals,
CAST(RIGHT('0' + CAST (FLOOR(TotalHoursAtWork) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalHoursAtWork * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalHoursAtWork * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalHoursAtWork,
CAST(RIGHT('0' + CAST (FLOOR(TotalOvertime) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalOvertime * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalOvertime * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalOvertime,
CAST(RIGHT('0' + CAST (FLOOR(TotalEarlyIn) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalEarlyIn * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalEarlyIn * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalEarlyIn,
CAST(RIGHT('0' + CAST (FLOOR(TotalLateIn) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalLateIn * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalLateIn * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalLateIn,
CAST(RIGHT('0' + CAST (FLOOR(TotalEarlyOut) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalEarlyOut * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalEarlyOut * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalEarlyOut,
CAST(RIGHT('0' + CAST (FLOOR(TotalLateOut) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalLateOut * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalLateOut * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalLateOut,
CAST(RIGHT('0' + CAST (FLOOR(TotalTimeOfPause) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalTimeOfPause * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalTimeOfPause * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalTimeOfPause,
CAST(RIGHT('0' + CAST (FLOOR(TotalMorePause) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalMorePause * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalMorePause * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalMorePause,
CAST(RIGHT('0' + CAST (FLOOR(TotalEarlyPauseOut) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalEarlyPauseOut * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalEarlyPauseOut * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalEarlyPauseOut,
CAST(RIGHT('0' + CAST (FLOOR(TotalLatePauseIn) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalLatePauseIn * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalLatePauseIn * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalLatePauseIn,
CAST(RIGHT('0' + CAST (FLOOR(TotalTimeOfOfficials) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalTimeOfOfficials * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalTimeOfOfficials * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalTimeOfOfficials,
CAST(RIGHT('0' + CAST (FLOOR(TotalTimeOfPersonals) AS VARCHAR), 3) + ':' + 
RIGHT('0' + CAST(FLOOR((((TotalTimeOfPersonals * 3600) % 3600) / 60)) AS VARCHAR), 2) + ':' + 
RIGHT('0' + CAST (FLOOR((TotalTimeOfPersonals * 3600) % 60) AS VARCHAR), 2) AS VARCHAR(10)) AS sTotalTimeOfPersonals
from #Report

drop table #Report
drop table #aaa
GO
