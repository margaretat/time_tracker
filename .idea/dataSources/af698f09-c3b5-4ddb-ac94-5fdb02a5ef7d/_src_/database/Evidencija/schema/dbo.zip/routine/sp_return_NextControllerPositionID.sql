CREATE PROCEDURE [dbo].[sp_return_NextControllerPositionID]
AS
DECLARE @i INT = 1

WHILE (SELECT COUNT(*) FROM Employees WHERE ControllerPositionID = @i) + (SELECT COUNT(*) FROM dbo.Visits WHERE ControllerPositionID = @i AND EndDateTime IS NULL) > 0
	SET @i = @i + 1
	
SELECT @i AS NextControllerPositionID
GO
