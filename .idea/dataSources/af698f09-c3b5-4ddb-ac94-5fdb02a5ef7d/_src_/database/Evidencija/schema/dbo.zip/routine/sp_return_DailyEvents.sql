CREATE PROCEDURE [dbo].[sp_return_DailyEvents] @Date DATE
AS
select e.Date, e.Time, c.Description as Controller, e.EventTypeID, et.Description as Event,
	e.EmployeeName as [Employee Name], e.CardNumber as [Card Number], e.Picture
from Events e
left outer join Controllers c on e.ControllerID = c.ControllerID
inner join EventTypes et on e.EventTypeID = et.EventTypeID
where e.Date = @Date AND ISNULL(DELETED, 0) = 0
order by e.Time desc
GO
