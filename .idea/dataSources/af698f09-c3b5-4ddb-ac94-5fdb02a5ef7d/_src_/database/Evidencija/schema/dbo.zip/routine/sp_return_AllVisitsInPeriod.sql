CREATE PROCEDURE [dbo].[sp_return_AllVisitsInPeriod] @DateTimeFrom DATETIME, @DateTimeTo DATETIME, @EmployeeID INT, @DepartmentID INT, @OnlyOpenVisits BIT
AS

SELECT v.*, d.Name AS 'Department Name', e.LastName + ' ' + e.FirstName AS 'Employee Name', c.CardNumber AS 'Card'
FROM dbo.Visits v
LEFT OUTER JOIN dbo.Departments d ON v.VisitingDepartmentID = d.DepartmentID
LEFT OUTER JOIN dbo.Employees e ON v.VisitingEmployeeID = e.EmployeeID
LEFT OUTER JOIN dbo.Cards c ON v.CardID = c.CardID
WHERE v.StartDateTime BETWEEN @DateTimeFrom AND @DateTimeTo
AND CASE WHEN @EmployeeID = 0 THEN v.VisitingEmployeeID ELSE @EmployeeID END = v.VisitingEmployeeID
AND CASE WHEN @DepartmentID = 0 THEN v.VisitingDepartmentID ELSE @DepartmentID END = v.VisitingDepartmentID
AND CASE WHEN @OnlyOpenVisits = 0 THEN 1 WHEN @OnlyOpenVisits = 1 AND v.EndDateTime IS NULL THEN 1 ELSE 0 END = 1
ORDER BY v.StartDateTime
GO
