CREATE PROCEDURE [dbo].[sp_return_WorkingHoursForEmployeeID] @EmployeeID INT
AS

SELECT WorkingHourID
FROM EmployeeWorkingHours
WHERE EmployeeID = @EmployeeID
GO
