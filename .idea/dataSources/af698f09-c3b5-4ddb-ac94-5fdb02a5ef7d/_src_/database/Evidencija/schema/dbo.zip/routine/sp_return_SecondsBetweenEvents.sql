CREATE PROCEDURE [dbo].[sp_return_SecondsBetweenEvents] @EmployeeID int, @DateTime datetime
AS

DECLARE @LastDT datetime

select @LastDT = cast(Date as datetime) + Time from events
where EmployeeID = @EmployeeID and cast(Date as datetime) + Time <= @DateTime

if @LastDT is null
	set @LastDT = '2000-01-01 00:00:00'

select abs(DateDiff(ss, @LastDT, @DateTime)) as Result
GO
