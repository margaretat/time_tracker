CREATE PROCEDURE [dbo].[sp_write_Holiday] @ReligionID INT, @Date DATE, @Description NVARCHAR(200)
AS

IF @Description = ''
	DELETE FROM Holidays
	WHERE ReligionID = @ReligionID
		AND Date = @Date
ELSE
	INSERT INTO Holidays (Date, ReligionID, Description)
	VALUES (@Date, @ReligionID, @Description)
GO
