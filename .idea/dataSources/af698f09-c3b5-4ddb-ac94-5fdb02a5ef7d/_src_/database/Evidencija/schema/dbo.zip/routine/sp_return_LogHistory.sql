CREATE PROCEDURE [dbo].[sp_return_LogHistory] @EventID INT
AS

SELECT  
		e.LogType,
		e.LogSysDateTime,
		e.MacAddr,
		e.ComputerName,
        e.ControllerID,
        e.Date,
        e.Time,
        e.UsedButton,
        e.EventTypeID,
        e.CardID,
        e.CardNumber,
        e.EmployeeID,
        e.EmployeeName,
        e.PersonalNumber,
        e.SysDateTime,
        e.RealEventTypeID,
        e.Deleted,
        e.ManualEntryUserID,
        e.ModifiedByUserID,
        c.DESCRIPTION AS 'Controller Name',
        et.Description AS 'Event',
        ume.UserName AS 'Manually Entered By',
        umod.UserName AS 'Last Modified By',
        eto.Description AS 'Original Event',
        e.RealDate AS 'Original Date',
        e.RealTime AS 'Original Time'

FROM dbo.LogEvents e
LEFT OUTER JOIN Controllers c ON e.ControllerID = c.ControllerID
INNER JOIN EventTypes et ON e.EventTypeID = et.EventTypeID
LEFT OUTER JOIN dbo.Users ume ON e.ManualEntryUserID = ume.UserID
LEFT OUTER JOIN dbo.Users umod ON e.ModifiedByUserID = umod.UserID
LEFT OUTER JOIN EventTypes eto ON e.RealEventTypeID = eto.EventTypeID
WHERE EventID = @EventID
ORDER BY LogEventID

GO
