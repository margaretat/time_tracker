CREATE PROCEDURE [dbo].[sp_return_Holidays] @ReligionID int, @Month int, @Year int
AS

select *
from Holidays
where ReligionID = @ReligionID
and month(Date) = @Month and year(Date) = @Year
GO
