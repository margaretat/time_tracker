CREATE TRIGGER [dbo].[trg_UDEvents] ON [dbo].[Events]
AFTER DELETE, UPDATE
AS
BEGIN
	DECLARE @Type CHAR(1), @MacAddr nvarchar(50)
	
	IF (SELECT COUNT(*) FROM INSERTED) = 0
		SET @Type = 'D'
	ELSE
		SET @Type = 'U'

	SELECT @MacAddr = net_address FROM sys.sysprocesses WHERE spid = @@SPID
	
	INSERT INTO LogEvents (
		LogType, MacAddr, EventID, ControllerID, Date, Time, UsedButton, EventTypeID, CardID, CardNumber,
		EmployeeID, EmployeeName, PersonalNumber, RealDate, RealTime, SysDateTime, RealEventTypeID, Deleted, ManualEntryUserID, ModifiedByUserID
	)
	SELECT
		@Type, @MacAddr, EventID, ControllerID, Date, Time, UsedButton, EventTypeID, CardID, CardNumber,
		EmployeeID, EmployeeName, PersonalNumber, RealDate, RealTime, SysDateTime, RealEventTypeID, Deleted, ManualEntryUserID, ModifiedByUserID
	FROM DELETED
END
GO
