CREATE PROCEDURE [dbo].[sp_return_Leaves] @BeginFrom DATE, @BeginTo DATE, @EndFrom DATE, @EndTo DATE, @EmployeeIDs VARCHAR(MAX),
	@LeaveTypeIDs VARCHAR(MAX), @ShowNoFinished BIT
AS

IF @BeginFrom IS NULL
	SET @BeginFrom = '2000.01.01'
IF @BeginTo IS NULL
	SET @BeginTo = '9999.12.31'
IF @EndFrom IS NULL
	SET @EndFrom = '2000.01.01'
IF @EndTo IS NULL
	SET @EndTo = '9999.12.31'

DECLARE @i INT, @s VARCHAR(100)

DECLARE @Employees TABLE (
	EmployeeID INT
)

WHILE @EmployeeIDs <> ''
BEGIN
	SET @i = CHARINDEX(',', @EmployeeIDs)
	if @i = 0
	BEGIN
		SET @s = RTRIM(LTRIM(@EmployeeIDs))
		SET @EmployeeIDs = ''
	END
	ELSE
	BEGIN
		SET @s = RTRIM(LTRIM(SUBSTRING(@EmployeeIDs, 1, @i-1)))
		SET @EmployeeIDs = SUBSTRING(@EmployeeIDs, @i+1, LEN(@EmployeeIDs))
	END
	
	SET @i = CAST(@s AS INT)
	INSERT INTO @Employees VALUES (@i)
END

DECLARE @LeaveTypes TABLE (
	LeaveTypeID INT
)

WHILE @LeaveTypeIDs <> ''
BEGIN
	SET @i = CHARINDEX(',', @LeaveTypeIDs)
	if @i = 0
	BEGIN
		SET @s = RTRIM(LTRIM(@LeaveTypeIDs))
		SET @LeaveTypeIDs = ''
	END
	ELSE
	BEGIN
		SET @s = RTRIM(LTRIM(SUBSTRING(@LeaveTypeIDs, 1, @i-1)))
		SET @LeaveTypeIDs = SUBSTRING(@LeaveTypeIDs, @i+1, LEN(@LeaveTypeIDs))
	END
	
	SET @i = CAST(@s AS INT)
	INSERT INTO @LeaveTypes VALUES (@i)
END

SELECT l.LeaveID, l.EmployeeID, l.LeaveTypeID, l.FromDate AS [Date from], l.ToDate AS [Date to], e.FirstName AS [First name], e.LastName AS [Last name],
	d.DepartmentID, d.Name AS Department, lt.Name AS [Leave type]
FROM dbo.Leaves l
INNER JOIN dbo.Employees e ON l.EmployeeID = e.EmployeeID
INNER JOIN dbo.Departments d ON e.DepartmentID = d.DepartmentID
INNER JOIN dbo.LeaveTypes lt ON l.LeaveTypeID = lt.LeaveTypeID
WHERE 1 = 1
AND FromDate BETWEEN @BeginFrom AND @BeginTo
AND (ToDate BETWEEN @EndFrom AND @EndTo OR (@ShowNoFinished = 1 AND ToDate IS NULL))
AND CASE WHEN NOT EXISTS(SELECT TOP 1 * FROM @Employees) THEN 1 WHEN l.EmployeeID IN (SELECT EmployeeID FROM @Employees) THEN 1 ELSE 0 END = 1
AND CASE WHEN NOT EXISTS(SELECT TOP 1 * FROM @LeaveTypes) THEN 1 WHEN l.LeaveTypeID IN (SELECT LeaveTypeID FROM @LeaveTypes) THEN 1 ELSE 0 END = 1
GO
