CREATE PROCEDURE [dbo].[sp_return_AllEventsInPeriod] @DateTimeFrom DATETIME, @DateTimeTo DATETIME, @EmployeeIDs NVARCHAR(MAX), @EventTypeID INT
AS

DECLARE @Employees TABLE (
	EmployeeID INT
)

DECLARE @s VARCHAR(100), @i INT

WHILE @EmployeeIDs <> ''
BEGIN
	SET @i = CHARINDEX(',', @EmployeeIDs)
	IF @i = 0
	BEGIN
		SET @s = RTRIM(LTRIM(@EmployeeIDs))
		SET @EmployeeIDs = ''
	END
	ELSE
	BEGIN
		SET @s = RTRIM(LTRIM(SUBSTRING(@EmployeeIDs, 1, @i-1)))
		SET @EmployeeIDs = SUBSTRING(@EmployeeIDs, @i+1, LEN(@EmployeeIDs))
	END
	
	SET @i = CAST(@s AS INT)
	INSERT INTO @Employees VALUES (@i)
END

SELECT  e.EventID,
        e.ControllerID,
        e.Date,
        e.Time,
        e.UsedButton,
        e.EventTypeID,
        e.CardID,
        e.CardNumber,
        e.EmployeeID,
        e.EmployeeName,
        e.PersonalNumber,
        e.SysDateTime,
        e.Picture,
        e.RealEventTypeID,
        e.Deleted,
        e.ManualEntryUserID,
        e.ModifiedByUserID,
        c.DESCRIPTION AS 'Controller Name',
        et.Description AS 'Event',
        ume.UserName AS 'Manually Entered By',
        umod.UserName AS 'Last Modified By',
        eto.Description AS 'Original Event',
        e.RealDate AS 'Original Date',
        e.RealTime AS 'Original Time'

FROM Events e
LEFT OUTER JOIN Controllers c ON e.ControllerID = c.ControllerID
INNER JOIN EventTypes et ON e.EventTypeID = et.EventTypeID
LEFT OUTER JOIN dbo.Users ume ON e.ManualEntryUserID = ume.UserID
LEFT OUTER JOIN dbo.Users umod ON e.ModifiedByUserID = umod.UserID
LEFT OUTER JOIN EventTypes eto ON e.RealEventTypeID = eto.EventTypeID
WHERE CAST(e.Date AS DATETIME) + CAST(e.Time AS DATETIME) BETWEEN @DateTimeFrom AND @DateTimeTo
AND CASE WHEN NOT EXISTS(SELECT TOP 1 * FROM @Employees) THEN 1 WHEN e.EmployeeID IN (SELECT EmployeeID FROM @Employees) THEN 1 ELSE 0 END = 1
AND ISNULL(Deleted, 0) = 0
AND (e.EventTypeID = @EventTypeID OR @EventTypeID < 0)
ORDER BY e.EmployeeName, e.Date, e.Time
GO
