CREATE PROCEDURE [dbo].[sp_return_AllAppointmentsInPeriod] @DateTimeFrom DATETIME, @DateTimeTo DATETIME, @EmployeeID INT, @DepartmentID INT
AS

SELECT a.*, d.Name AS 'Department Name', e.LastName + ' ' + e.FirstName AS 'Employee Name'
FROM dbo.Appointments a
LEFT OUTER JOIN dbo.Departments d ON a.VisitingDepartmentID = d.DepartmentID
LEFT OUTER JOIN dbo.Employees e ON a.VisitingEmployeeID = e.EmployeeID
WHERE a.VisitingDateTime BETWEEN @DateTimeFrom AND @DateTimeTo
AND CASE WHEN @EmployeeID = 0 THEN a.VisitingEmployeeID ELSE @EmployeeID END = a.VisitingEmployeeID
AND CASE WHEN @DepartmentID = 0 THEN a.VisitingDepartmentID ELSE @DepartmentID END = a.VisitingDepartmentID
ORDER BY a.VisitingDateTime
GO
